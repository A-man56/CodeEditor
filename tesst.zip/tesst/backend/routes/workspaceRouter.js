const express = require('express');
const router = express.Router();
const fs = require('fs-extra');
const path = require('path');
const simpleGit = require('simple-git');
const { exec } = require('child_process');

const TEMP_DIR = path.join(__dirname, '..', 'temp-projects');
const CLONE_TEMP = path.join(__dirname, '..', 'clones-temp'); // temp folder to clone full repo

// Ensure folders exist
fs.ensureDirSync(TEMP_DIR);
fs.ensureDirSync(CLONE_TEMP);

const FOLDER_MAP = {
  'React': 'react-app',
  'Node.js': 'node',
  'Python': 'python',
  'C++': 'cpp'
};

const REPO_URL = 'https://github.com/A-man56/code-templates.git';

router.post('/create', async (req, res) => {
  const { techStack, projectId } = req.body;

  // Validate projectId and techStack
  if (!projectId) {
    return res.status(400).json({ message: 'Project ID is required' });
  }

  if (!FOLDER_MAP[techStack]) {
    return res.status(400).json({ message: 'Invalid tech stack' });
  }

  const subFolder = FOLDER_MAP[techStack];
  const projectFolder = path.join(TEMP_DIR, projectId);
  const clonePath = path.join(CLONE_TEMP, `${projectId}-clone`);

  console.log('TEMP_DIR:', TEMP_DIR);
  console.log('CLONE_TEMP:', CLONE_TEMP);
  console.log('projectId:', projectId);

  try {
    // Clone full repo into a temp folder
    await simpleGit().clone(REPO_URL, clonePath);

    const sourceSubfolder = path.join(clonePath, subFolder);
    if (!fs.existsSync(sourceSubfolder)) {
      return res.status(500).json({ message: 'Template folder not found in repo' });
    }

    // Copy only the subfolder to the user's project folder
    await fs.copy(sourceSubfolder, projectFolder);

    // Clean up clone folder
    await fs.remove(clonePath);

    // Optional: Run npm install for React/Node.js
    if (techStack === 'React' || techStack === 'Node.js') {
      exec('npm install', { cwd: projectFolder }, (err, stdout, stderr) => {
        if (err) {
          console.error('npm install error:', err);
          console.error('stderr:', stderr);
          return res.status(500).json({ message: 'Project created, but npm install failed' });
        }
        console.log('npm install output:', stdout);
        return res.json({ message: 'Project created successfully with npm install!' });
      });
    } else {
      return res.json({ message: 'Project created successfully!' });
    }

  } catch (error) {
    console.error('Project creation failed:', error);
    return res.status(500).json({ message: 'Project creation failed', error: error.message });
  }
});

module.exports = router;
