const express = require('express');
const app = express();
const bodyParser = require('body-parser');
require('dotenv').config();
require('./model/db');
const cors = require('cors');
const authRouter = require('./routes/authRouter');
const workspaceRouter = require('./routes/workspaceRouter'); // ✅ NEW

const path = require('path');
const fs = require('fs-extra');

const PORT = process.env.PORT || 3500;

// ========== MIDDLEWARES ==========
app.use(bodyParser.json({ limit: '50mb' }));
app.use(cors());
app.use('/auth', authRouter);
app.use('/api', require('./routes/workspaceRouter'));

// ========== CREATE FOLDERS IF NOT EXIST ==========
const TEMP_PROJECTS_DIR = path.join(__dirname, 'temp-projects');
const CLONE_TEMP_DIR = path.join(__dirname, 'clones-temp');

if (!fs.existsSync(TEMP_PROJECTS_DIR)) fs.mkdirSync(TEMP_PROJECTS_DIR);
if (!fs.existsSync(CLONE_TEMP_DIR)) fs.mkdirSync(CLONE_TEMP_DIR);

// ========== ROOT ROUTE TEST ==========
app.get('/root', (req, res) => {
  res.send('Hello world from root route');
});

// ========== START SERVER ==========
app.listen(PORT, () => {
  console.log(`🚀 Server is running on http://localhost:${PORT}`);
});
